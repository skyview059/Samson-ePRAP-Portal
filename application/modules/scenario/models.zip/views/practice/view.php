<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<section class="content-header">
    <h1>
        <?php echo $exam_name; ?> - Practice Scenario Topics <small>Control panel</small>

        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_new_group_modal">
            <i class="fa fa-plus"></i> Add New Topic
        </button>
        <a class="btn btn-default" href="<?php echo site_url('admin/scenario/practice')?>">Back</a>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo site_url(Backend_URL) ?>"><i class="fa fa-dashboard"></i> Admin</a></li>
        <li><a href="<?php echo site_url(Backend_URL . 'scenario/practice') ?>">Practice Scenarios</a></li>
        <li class="active">Topic</li>
    </ol>
</section>

<section class="content">
    <div class="panel panel-default">
        <div class="panel-heading"><?php echo $exam_name; ?> - Topics</div>

        <div class="panel-body">
            <?php if ($topics) { ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-condensed" id="ordering">
                        <thead>
                        <tr>
                            <th width="50">S/L</th>
                            <th>Topic Name</th>
                            <th class="text-center" width="100">Scenarios</th>
                            <th width="150">Created at</th>
                            <th class="text-center" width="250">Action</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $start = 0;
                        foreach ($topics as $topic) { ?>
                            <tr id="item-<?= $topic->id; ?>">
                                <td><i class="fa fa-arrows-v"></i> <?php echo sprintf('%03d', ++$start); ?></td>
                                <td><?php echo $topic->name; ?></td>
                                <td class="text-center">
                                    <label class="label label-default">
                                        <?php echo ($topic->scenarios); ?>
                                    </label>
                                </td>
                                <td><?php echo globalDateTimeFormat($topic->created_at); ?></td>
                                <td class="text-center">
                                    <?php echo anchor(site_url(
                                            Backend_URL . "scenario/practice/topic/{$exam_id}/{$topic->id}"), 
                                            '<i class="fa fa-fw fa-edit"></i> Edit / Assign Scenarios', 
                                            'class="btn btn-xs btn-default" title="Edit"'
                                        );
                                    ?>
                                    <button type="button" onClick="delete_topic(<?php echo $topic->id; ?>)"
                                            class="btn btn-danger btn-xs" title="Delete Topic">
                                            <i class="fa fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>

                </div>
            <?php } else { ?>
                <div class="box-body">
                    <p class="ajax_notice"> No Topic found at this Centre.</p>
                </div>
            <?php } ?>
        </div>
    </div>
</section>

<div class="modal fade" id="add_new_group_modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <?php echo form_open(Backend_URL . 'scenario/practice/create_group_action', array('class' => 'form-horizontal', 'method' => 'post', 'id' => 'create_group_from')); ?>
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Add New Topic</h4>
            </div>
            <div class="modal-body">
                <div class="form-group row">
                    <label for="topic_name" class="col-sm-3 control-label">Topic Name<sup>*</sup></label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="topic_name" name="topic_name">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" name="exam_id" id="exam_id" value="<?php echo $exam_id; ?>"/>
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Create</button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>

<script type="application/javascript">
    function delete_topic(id){
        if(confirm('Are you sure to delete this topic?')){
            $.ajax({
                url: 'admin/scenario/practice/topic_delete',
                type: 'POST',
                data: {id: id},
                success: function (response) {
                    if(response === 'OK'){
                        toastr.success('Topic Deleted Successfully!');
                        location.reload();
                    }else{
                        toastr.error('Topic Could not Deleted!');
                    }
                }
            });
        }
    }

    $(document).ready(function () {
        $("#ordering tbody").sortable({
            axis  : "y",
            update: function (event, ui) {
                const data = $(this).sortable('serialize');
                $.ajax({
                    data   : data,
                    type   : 'POST',
                    url    : 'admin/scenario/practice/group_save_order',
                    success: function (response) {
                        console.log(response);
                        toastr.success("Order Saved Successfully!");
                    }
                });
            }
        });
    });

    $(document).on('submit', '#create_group_from', function () {
        const topic_name = $('#topic_name').val();
        const exam_id    = $('#exam_id').val();

        if (topic_name === '') {
            toastr.error("Please enter topic name!");
            return false;
        }

        $.ajax({
            url       : 'admin/scenario/practice/topic_create_action',
            type      : 'POST',
            dataType  : 'json',
            data      : {topic_name: topic_name, exam_id: exam_id},
            beforeSend: function () {
                toastr.warning("Please Loading...");
            },
            success   : function (jsonRespond) {
                if (jsonRespond.Status === 'OK') {
                    $('#add_new_group_modal').modal('hide');
                    toastr.success("Group Created Successfully!");
                    location.reload();
                } else {
                    toastr.error("Topic Could not Created");
                }
            }
        });
        return false;
    });
</script>