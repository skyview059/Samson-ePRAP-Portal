<?php defined('BASEPATH') or exit('No direct script access allowed');

/* Author: Khairul Azam
 * Date : 2020-01-16 application/modules/scenario/controllers/Scenario.php
 */

class Practice extends Admin_controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Scenario_model');
        $this->load->model('Practice_model');
        $this->load->helper('scenario');
        $this->load->helper('exam/exam');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['exams'] = $this->Practice_model->get_exam_list();
        $this->viewAdminContent('scenario/practice/index', $data);
    }

    public function practice_view($exam_id)
    {
        $data['exam_id']   = $exam_id;
        $data['exam_name'] = getExamName($exam_id);
        $data['topics']    = $this->Practice_model->get_topic_scenarios( $exam_id );

        $this->viewAdminContent('scenario/practice/view', $data);
    }

    public function practice_topic_items($exam_id, $topic_id)
    {
        $row = $this->db->get_where('scenario_topics', array('id' => $topic_id))->row();
        if ($row) {
            $data['exam_name'] = getExamName($exam_id);
            $data['id']        = $topic_id;
            $data['name']      = set_value('name', $row->name);
            $data['exam_id']   = set_value('exam_id', $row->exam_id);
            $data['button']    = 'Update';

            $data['action']    = site_url(Backend_URL . 'scenario/practice/topic_update_action');
            $data['scenarios'] = $this->getScenarios($exam_id);
            $data['items']     = $this->getScenarioTopicItems($exam_id, $topic_id);
            $this->viewAdminContent('scenario/practice/topic_items', $data);
        } else {
            $this->session->set_flashdata('msge', 'Invalid topic ID');
            redirect(Backend_URL . 'scenario/practice/view/' . $exam_id);
        }
    }

    private function getScenarios($exam_id)
    {
        return $this->db->select('id, name')->get_where('scenarios', array('exam_id' => $exam_id))->result();
    }

    private function getScenarioTopicItems($exam_id, $topic_id)
    {
        return $this->db->select('scenario_topics_items.id, scenarios.name, scenario_topics_items.custom_title, scenario_topics_items.order')
            ->from('scenario_topics_items')
            ->join('scenarios', 'scenarios.id = scenario_topics_items.scenario_id')
            ->where('scenario_topics_items.scenario_topic_id', $topic_id)
            ->where('scenarios.exam_id', $exam_id)
            ->order_by('scenario_topics_items.order', 'ASC')
            ->get()->result();
    }

    public function topic_update_action()
    {
        $id      = intval($this->input->post('id', TRUE));
        $exam_id = intval($this->input->post('exam_id', TRUE));
        $this->form_validation->set_rules('exam_id', 'Exam', 'trim|required');
        $this->form_validation->set_rules('name', 'topic Name', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->practice_topic_items($exam_id, $id);
        } else {
            $data = array(
                'exam_id'    => $exam_id,
                'name'       => $this->input->post('name', TRUE),
                'updated_at' => date('Y-m-d H:i:s')
            );
            $this->db->where('id', $id)->update('scenario_topics', $data);
            $this->session->set_flashdata('msgs', 'Scenario topic Updated Successfully');
            redirect(site_url(Backend_URL . 'scenario/practice/topic/' . $exam_id . '/' . $id));
        }
    }

    public function topic_item_add_action()
    {
        $id      = intval($this->input->post('id', TRUE));
        $exam_id = intval($this->input->post('exam_id', TRUE));
        $this->form_validation->set_rules('exam_id', 'Exam', 'trim|required');
        $this->form_validation->set_rules('scenario_id', 'Scenario', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->practice_topic_items($exam_id, $id);
        } else {
            $custom_title = $this->input->post('custom_title', TRUE);
            $scenario_id  = intval($this->input->post('scenario_id', TRUE));
            $data         = array(
                'exam_id'           => $exam_id,
                'scenario_topic_id' => $id,
                'scenario_id'       => $scenario_id,
                'custom_title'      => ($custom_title) ?: getScenarioName($scenario_id),
                'order'             => 9999,
            );
            $this->db->insert('scenario_topics_items', $data);

            $this->session->set_flashdata('msgs', 'Item Added Successfully!');
            redirect(site_url(Backend_URL . 'scenario/practice/topic/' . $exam_id . '/' . $id));
        }
    }

    public function topic_create_action()
    {
        ajaxAuthorized();
        $this->form_validation->set_rules('exam_id', 'Exam', 'trim|required');
        $this->form_validation->set_rules('topic_name', 'topic Name', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            echo ajaxRespond('FAIL', validation_errors());
        } else {
            $data = array(
                'exam_id'    => intval($this->input->post('exam_id')),
                'name'       => $this->input->post('topic_name'),
                'created_at' => date('Y-m-d H:i:s')
            );
            $this->db->insert('scenario_topics', $data);
            echo ajaxRespond('OK', 'topic has been created successfully.');
        }
    }

    public function topic_save_order()
    {
        $items    = $this->input->post('item');
        $reorder  = [];
        $order_id = 0;
        foreach ($items as $item) {
            $reorder[] = [
                'id'    => $item,
                'order' => ++$order_id,
            ];
        }

        $this->db->update_batch('scenario_topics', $reorder, 'id');
    }

    public function topic_items_save_order()
    {
        $items    = $this->input->post('item');
        $reorder  = [];
        $order_id = 0;
        foreach ($items as $item) {
            $reorder[] = [
                'id'    => $item,
                'order' => ++$order_id,
            ];
        }
        $this->db->update_batch('scenario_topics_items', $reorder, 'id');
    }

    public function rename_custom_title()
    {
        ajaxAuthorized();
        $id  = intval($this->input->post('id'));
        $row = $this->db->get_where('scenario_topics_items', ['id' => $id])->row();

        echo '<input class="form-control" id="custom_title_input_'.$id.'" value="' . $row->custom_title . '" type="text"><button class="btn btn-success btn-sm" onclick="update_custom_title(' . $id . ')" type="button" >Save</button>';
    }

    public function rename_custom_title_action()
    {
        ajaxAuthorized();

        $custom_title = $this->input->post('custom_title');
        $id           = intval($this->input->post('id'));
        $data         = ['custom_title' => $custom_title];
        $this->db->update('scenario_topics_items', $data, ['id' => $id]);
        echo ajaxRespond('OK', '<span style="color:green"><i class="fa fa-check-square-o"></i></span> ' . $custom_title);
    }

    public function topic_item_delete()
    {
        ajaxAuthorized();
        $id = intval($this->input->post('id'));
        $this->db->delete('scenario_topics_items', ['id' => $id]);
        echo ajaxRespond('OK', 'Item Deleted Successfully');
    }

    public function topic_delete()
    {
        ajaxAuthorized();
        $id = intval($this->input->post('id'));
        $this->db->delete('scenario_topics', ['id' => $id]);
        $this->db->delete('scenario_topics_items', ['scenario_topic_id' => $id]);

        echo ajaxRespond('OK', 'topic Deleted Successfully');
    }
}