<style type="text/css">
    td.doc2html {
        background: #EEE;
        padding: 25px !important;
    }
    td.doc2html>div.bg {
        background: #FFF;
        padding: 25px !important;
        border: 1px solid #CCC;
    }
    td.doc2html>div.bg ul {
        padding: 15px;
        margin-left: 15px;
    }
    td.doc2html>div.bg ul li {
        list-style-type: disc;
    }
    td.doc2html>div.bg ol {
        padding: 15px;
        margin-left: 15px;
    }
    td.doc2html>div.bg ol li {
        list-style-type: decimal;
    }    
</style>