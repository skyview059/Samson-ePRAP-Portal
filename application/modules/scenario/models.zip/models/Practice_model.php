<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Practice_model extends Fm_model
{
    public $table = '';
    public $id = 'id';
    public $order = 'ASC';

    function __construct()
    {
        parent::__construct();
    }

    function get_exam_list(){

        $this->db->select('count(*)');        
        $this->db->where('exam_id', "exams.id", false);        
        $topics = $this->db->get_compiled_select('scenario_topics'); 

        $this->db->select('count(*)');        
        $this->db->where('exam_id', "exams.id", false);        
        $scenarios = $this->db->get_compiled_select('scenario_topics_items'); 

        $this->db->select('id, name');  
        $this->db->select("({$topics}) as topics");        
        $this->db->select("({$scenarios}) as scenarios");        
        return $this->db->get('exams')->result();
    }

    function get_topic_scenarios(  $exam_id ){

        $this->db->select('count(*)');        
        $this->db->where('exam_id', 'scenario_topics.exam_id', false);        
        $scenarios = $this->db->get_compiled_select('scenario_topics_items'); 

        $this->db->select('id, name, created_at');                
        $this->db->select("({$scenarios}) as scenarios");

        $this->db->select('exam_id',$exam_id );        
        $this->db->order_by('order', 'ASC');
        return $this->db->get('scenario_topics')->result();
    }
}