<?php

defined('BASEPATH') OR exit('No direct script access allowed');

function scenarioTabs($id, $active_tab)
{
    $html = '<ul class="nav nav-tabs admintab">';
    $tabs = [
        'read' => 'Details',
        'update' => 'Update',
        'delete' => 'Delete',
    ];

    foreach ($tabs as $link => $tab) {
        $html .= '<li><a href="' . Backend_URL . "scenario/{$link}/{$id}\"";
        $html .= ($link == $active_tab ) ? ' class="active"' : '';
        $html .= '>' . $tab . '</a></li>';
    }
    $html .= '</ul>';
    return $html;
}

function scenarioDelBtn( $id, $used ){
    if($used){
        echo '<span class="btn btn-xs btn-danger disabled"> &nbsp;<i class="fa fa-lock"></i> &nbsp;</span>';
    } else {
        echo '<span onclick="return delScen('.$id.');" class="btn btn-xs btn-danger"> &nbsp;<i class="fa fa-times"></i>&nbsp; </span>';
    }
}

function getScenarioGroupName($id) {
    $ci = & get_instance();
    $row = $ci->db->where('id', $id)->get('scenario_topics')->row();
    if($row){
        return $row->name;
    } else {
        return "Unknown";
    }
}

function getScenarioName($id) {
    $ci = & get_instance();
    $row = $ci->db->where('id', $id)->get('scenarios')->row();
    if($row){
        return $row->name;
    } else {
        return "Unknown";
    }
}

// function countScenarioGroups($id) {
//     $ci = & get_instance();
//     return $ci->db->where('exam_id', $id)->count_all_results('scenario_topics');
// }

// function countScenariosByExam($id) {
//     $ci = & get_instance();
//     return $ci->db->where('exam_id', $id)->count_all_results('scenario_topics_items');
// }

// function countScenarioGroupQuestions($id) {
//     $ci = & get_instance();
//     return $ci->db->where('scenario_topic_id', $id)->count_all_results('scenario_topics_items');
// }